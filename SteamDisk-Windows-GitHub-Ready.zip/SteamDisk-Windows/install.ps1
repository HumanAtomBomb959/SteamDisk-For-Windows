$Source = Split-Path -Parent $MyInvocation.MyCommand.Path
$Target = "C:\SteamDisk"
$Startup = [Environment]::GetFolderPath("Startup")
New-Item -ItemType Directory -Path $Target -Force | Out-Null
Copy-Item "$Source\SteamDisk.ps1" "$Target\SteamDisk.ps1" -Force
Copy-Item "$Source\StartSteamDisk.vbs" "$Target\StartSteamDisk.vbs" -Force
$wsh = New-Object -ComObject WScript.Shell
$shortcut = $wsh.CreateShortcut((Join-Path $Startup "SteamDisk.lnk"))
$shortcut.TargetPath = "$Target\StartSteamDisk.vbs"
$shortcut.WorkingDirectory = $Target
$shortcut.Description = "SteamDisk floppy launcher"
$shortcut.Save()
Write-Host "SteamDisk installed to $Target"
