$FloppyDrive = "A:"
$DiskFile = Join-Path $FloppyDrive "disk.ini"
$PollSeconds = 1

function Get-IniValue {
    param([string[]]$Lines, [string]$Key)
    $line = $Lines | Where-Object { $_ -match ("^\s*" + [regex]::Escape($Key) + "\s*=") } | Select-Object -First 1
    if ($null -eq $line) { return $null }
    ($line -replace ("^\s*" + [regex]::Escape($Key) + "\s*=\s*"), "").Trim()
}

function Read-SteamDisk {
    param([string]$Path)
    $lines = Get-Content -LiteralPath $Path -ErrorAction Stop
    [pscustomobject]@{
        Game     = Get-IniValue $lines "Game"
        Launcher = Get-IniValue $lines "Launcher"
        AppID    = Get-IniValue $lines "AppID"
    }
}

Write-Host "SteamDisk for Windows"
Write-Host "Watching $FloppyDrive..."
Write-Host ""

while ($true) {
    if (Test-Path -LiteralPath $DiskFile) {
        try {
            $disk = Read-SteamDisk $DiskFile

            if ($disk.Launcher -eq "Steam" -and $disk.AppID -match '^\d+$') {
                Write-Host "SteamDisk detected!"
                Write-Host "Game: $($disk.Game)"
                Write-Host "AppID: $($disk.AppID)"
                Start-Process "steam://rungameid/$($disk.AppID)"
                Write-Host "Game launched. Remove the SteamDisk to load another game."

                while (Test-Path -LiteralPath $DiskFile) {
                    Start-Sleep -Seconds $PollSeconds
                }

                Write-Host "SteamDisk removed."
                Write-Host "Ready for next disk."
                Write-Host ""
            }
            else {
                while (Test-Path -LiteralPath $DiskFile) {
                    Start-Sleep -Seconds $PollSeconds
                }
            }
        } catch {
            Start-Sleep -Seconds 2
        }
    }
    Start-Sleep -Seconds $PollSeconds
}
