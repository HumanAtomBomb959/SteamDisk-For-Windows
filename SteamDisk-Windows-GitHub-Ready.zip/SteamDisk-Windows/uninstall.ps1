$Target = "C:\SteamDisk"
$Startup = [Environment]::GetFolderPath("Startup")
Remove-Item (Join-Path $Startup "SteamDisk.lnk") -Force -ErrorAction SilentlyContinue
Remove-Item $Target -Recurse -Force -ErrorAction SilentlyContinue
Write-Host "SteamDisk removed."
