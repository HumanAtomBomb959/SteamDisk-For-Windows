# SteamDisk for Windows

Physical floppy disks act as launch keys for Steam games and other software represented by Steam shortcuts.

## Disk format

```ini
[SteamDisk]
Game=Black Reliquary
Launcher=Steam
AppID=2119270
```

`AppID` must be an ID that works with `steam://rungameid/<AppID>`.

## Install

Run PowerShell in this folder:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\install.ps1
```

SteamDisk installs to `C:\SteamDisk` and creates a shortcut in the current user's Startup folder.

## Test manually

```powershell
powershell.exe -ExecutionPolicy Bypass -File C:\SteamDisk\SteamDisk.ps1
```

Insert a SteamDisk into drive `A:`. The watcher reads `disk.ini`, launches Steam, and waits for the disk to be removed before accepting another disk.

## Uninstall

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\uninstall.ps1
```

## Architecture

Steam is the universal launcher layer. A disk can therefore represent a normal Steam game, a Steam non-Steam shortcut, a RetroArch game added to Steam, or another Windows application added to Steam.

SteamDisk itself only reads `A:\disk.ini`; it does not modify the floppy.

## License

MIT. See `LICENSE`.
